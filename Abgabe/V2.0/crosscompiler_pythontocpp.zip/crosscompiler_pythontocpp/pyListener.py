# Generated from java-escape by ANTLR 4.4
from antlr4 import *

# This class defines a complete listener for a parse tree produced by pyParser.
class pyListener(ParseTreeListener):

    # Enter a parse tree produced by pyParser#tuple_.
    def enterTuple_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#tuple_.
    def exitTuple_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#assert_stmt.
    def enterAssert_stmt(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#assert_stmt.
    def exitAssert_stmt(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#set_.
    def enterSet_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#set_.
    def exitSet_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#index__is__expr.
    def enterIndex__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#index__is__expr.
    def exitIndex__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#gen_expr.
    def enterGen_expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#gen_expr.
    def exitGen_expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#raise_stmt.
    def enterRaise_stmt(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#raise_stmt.
    def exitRaise_stmt(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#number.
    def enterNumber(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#number.
    def exitNumber(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#list_gen.
    def enterList_gen(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#list_gen.
    def exitList_gen(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#funccall__is__expr.
    def enterFunccall__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#funccall__is__expr.
    def exitFunccall__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#func_stmt.
    def enterFunc_stmt(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#func_stmt.
    def exitFunc_stmt(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#elif_.
    def enterElif_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#elif_.
    def exitElif_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#block.
    def enterBlock(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#block.
    def exitBlock(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#bit_and__is__expr.
    def enterBit_and__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#bit_and__is__expr.
    def exitBit_and__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#val.
    def enterVal(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#val.
    def exitVal(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#var.
    def enterVar(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#var.
    def exitVar(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#module.
    def enterModule(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#module.
    def exitModule(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#vartuple.
    def enterVartuple(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#vartuple.
    def exitVartuple(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#op_cmp.
    def enterOp_cmp(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#op_cmp.
    def exitOp_cmp(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#paramlist.
    def enterParamlist(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#paramlist.
    def exitParamlist(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#str_prefix.
    def enterStr_prefix(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#str_prefix.
    def exitStr_prefix(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#dictitem.
    def enterDictitem(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#dictitem.
    def exitDictitem(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#ifelse.
    def enterIfelse(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#ifelse.
    def exitIfelse(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#ternary__is__expr.
    def enterTernary__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#ternary__is__expr.
    def exitTernary__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#global_stmt.
    def enterGlobal_stmt(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#global_stmt.
    def exitGlobal_stmt(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#and__is__expr.
    def enterAnd__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#and__is__expr.
    def exitAnd__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#karg.
    def enterKarg(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#karg.
    def exitKarg(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#decorator.
    def enterDecorator(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#decorator.
    def exitDecorator(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#exprlist.
    def enterExprlist(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#exprlist.
    def exitExprlist(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#trycatch.
    def enterTrycatch(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#trycatch.
    def exitTrycatch(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#blockend.
    def enterBlockend(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#blockend.
    def exitBlockend(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#pos_arg.
    def enterPos_arg(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#pos_arg.
    def exitPos_arg(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#or__is__expr.
    def enterOr__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#or__is__expr.
    def exitOr__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#dash_calc__is__expr.
    def enterDash_calc__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#dash_calc__is__expr.
    def exitDash_calc__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#arglist.
    def enterArglist(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#arglist.
    def exitArglist(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#pos_paramlist.
    def enterPos_paramlist(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#pos_paramlist.
    def exitPos_paramlist(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#except_.
    def enterExcept_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#except_.
    def exitExcept_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#varlist.
    def enterVarlist(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#varlist.
    def exitVarlist(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#brackets__is__expr.
    def enterBrackets__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#brackets__is__expr.
    def exitBrackets__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#print_stmt.
    def enterPrint_stmt(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#print_stmt.
    def exitPrint_stmt(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#int_.
    def enterInt_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#int_.
    def exitInt_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#loop_stmt.
    def enterLoop_stmt(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#loop_stmt.
    def exitLoop_stmt(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#pass_stmt.
    def enterPass_stmt(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#pass_stmt.
    def exitPass_stmt(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#slice_.
    def enterSlice_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#slice_.
    def exitSlice_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#prog.
    def enterProg(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#prog.
    def exitProg(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#exec_stmt.
    def enterExec_stmt(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#exec_stmt.
    def exitExec_stmt(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#mod_list.
    def enterMod_list(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#mod_list.
    def exitMod_list(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#else_.
    def enterElse_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#else_.
    def exitElse_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#for_.
    def enterFor_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#for_.
    def exitFor_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#mod_alias.
    def enterMod_alias(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#mod_alias.
    def exitMod_alias(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#pos_paramtuple.
    def enterPos_paramtuple(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#pos_paramtuple.
    def exitPos_paramtuple(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#block_stmt.
    def enterBlock_stmt(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#block_stmt.
    def exitBlock_stmt(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#kparamlist.
    def enterKparamlist(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#kparamlist.
    def exitKparamlist(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#loop.
    def enterLoop(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#loop.
    def exitLoop(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#import_.
    def enterImport_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#import_.
    def exitImport_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#single_stmt.
    def enterSingle_stmt(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#single_stmt.
    def exitSingle_stmt(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#not__is__expr.
    def enterNot__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#not__is__expr.
    def exitNot__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#bit_xor__is__expr.
    def enterBit_xor__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#bit_xor__is__expr.
    def exitBit_xor__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#assign_stmt.
    def enterAssign_stmt(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#assign_stmt.
    def exitAssign_stmt(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#lambda_label__is__expr.
    def enterLambda_label__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#lambda_label__is__expr.
    def exitLambda_label__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#list_.
    def enterList_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#list_.
    def exitList_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#attr__is__expr.
    def enterAttr__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#attr__is__expr.
    def exitAttr__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#dict_gen.
    def enterDict_gen(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#dict_gen.
    def exitDict_gen(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#id_.
    def enterId_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#id_.
    def exitId_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#set_gen.
    def enterSet_gen(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#set_gen.
    def exitSet_gen(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#shift__is__expr.
    def enterShift__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#shift__is__expr.
    def exitShift__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#exponentiation__is__expr.
    def enterExponentiation__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#exponentiation__is__expr.
    def exitExponentiation__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#simple_var.
    def enterSimple_var(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#simple_var.
    def exitSimple_var(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#import_stmt.
    def enterImport_stmt(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#import_stmt.
    def exitImport_stmt(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#unary__is__expr.
    def enterUnary__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#unary__is__expr.
    def exitUnary__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#lambda_.
    def enterLambda_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#lambda_.
    def exitLambda_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#bit_or__is__expr.
    def enterBit_or__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#bit_or__is__expr.
    def exitBit_or__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#while_.
    def enterWhile_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#while_.
    def exitWhile_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#float_.
    def enterFloat_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#float_.
    def exitFloat_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#rel_module.
    def enterRel_module(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#rel_module.
    def exitRel_module(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#dictlist.
    def enterDictlist(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#dictlist.
    def exitDictlist(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#dot_calc__is__expr.
    def enterDot_calc__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#dot_calc__is__expr.
    def exitDot_calc__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#str_val.
    def enterStr_val(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#str_val.
    def exitStr_val(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#id_list.
    def enterId_list(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#id_list.
    def exitId_list(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#string.
    def enterString(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#string.
    def exitString(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#generator.
    def enterGenerator(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#generator.
    def exitGenerator(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#aug_op.
    def enterAug_op(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#aug_op.
    def exitAug_op(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#aug_assign.
    def enterAug_assign(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#aug_assign.
    def exitAug_assign(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#val_label__is__expr.
    def enterVal_label__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#val_label__is__expr.
    def exitVal_label__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#iter_gen.
    def enterIter_gen(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#iter_gen.
    def exitIter_gen(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#alias_list.
    def enterAlias_list(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#alias_list.
    def exitAlias_list(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#alias.
    def enterAlias(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#alias.
    def exitAlias(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#comparison__is__expr.
    def enterComparison__is__expr(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#comparison__is__expr.
    def exitComparison__is__expr(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#dict_.
    def enterDict_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#dict_.
    def exitDict_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#id_alias.
    def enterId_alias(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#id_alias.
    def exitId_alias(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#pos_arglist.
    def enterPos_arglist(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#pos_arglist.
    def exitPos_arglist(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#if_.
    def enterIf_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#if_.
    def exitIf_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#with_.
    def enterWith_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#with_.
    def exitWith_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#class_.
    def enterClass_(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#class_.
    def exitClass_(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#karglist.
    def enterKarglist(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#karglist.
    def exitKarglist(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#kparam.
    def enterKparam(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#kparam.
    def exitKparam(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#blockbegin.
    def enterBlockbegin(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#blockbegin.
    def exitBlockbegin(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#func.
    def enterFunc(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#func.
    def exitFunc(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#del_stmt.
    def enterDel_stmt(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#del_stmt.
    def exitDel_stmt(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#block_head.
    def enterBlock_head(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#block_head.
    def exitBlock_head(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#stmt.
    def enterStmt(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#stmt.
    def exitStmt(self, ctx):
        pass


    # Enter a parse tree produced by pyParser#assign.
    def enterAssign(self, ctx):
        pass

    # Exit a parse tree produced by pyParser#assign.
    def exitAssign(self, ctx):
        pass


