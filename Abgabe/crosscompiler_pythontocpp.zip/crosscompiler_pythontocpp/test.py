

r'abc';
u"""
asdad

""";

x if x else y;
[x for x in range(11) if x%2];
#2+4*3;

#a,b[0]=1,2;
#2+4*5/a*f[:][0::2];

#g(*a,b,d=[1*3,4])+2 * 3;

#def f( a,b, (c,d)=(1,2), e=3 )